/*
 * APD - Tema 1
 * Octombrie 2020
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>

#define min(X, Y) (((X) < (Y)) ? (X) : (Y))

char *in_filename_julia;
char *in_filename_mandelbrot;
char *out_filename_julia;
char *out_filename_mandelbrot;
int NUM_THREADS;

int height_julia, width_julia;
int height_mandelbrot, width_mandelbrot;

int **result_julia;
int **result_mandelbrot;

pthread_barrier_t barrier;

// structura pentru un numar complex
typedef struct _complex {
	double a;
	double b;
} complex;

// structura pentru parametrii unei rulari
typedef struct _params {
	int is_julia, iterations;
	double x_min, x_max, y_min, y_max, resolution;
	complex c_julia;
} params;

params *par_julia;
params *par_mandelbrot;

// citeste argumentele programului
void get_args(int argc, char **argv)
{
	if (argc < 6) {
		printf("Numar insuficient de parametri:\n\t"
				"./tema1 fisier_intrare_julia fisier_iesire_julia "
				"fisier_intrare_mandelbrot fisier_iesire_mandelbrot\n");
		exit(1);
	}

	in_filename_julia = argv[1];
	out_filename_julia = argv[2];
	in_filename_mandelbrot = argv[3];
	out_filename_mandelbrot = argv[4];
	NUM_THREADS = atoi(argv[5]);
}

// citeste fisierul de intrare
void read_input_file(char *in_filename, params* par)
{
	FILE *file = fopen(in_filename, "r");
	if (file == NULL) {
		printf("Eroare la deschiderea fisierului de intrare!\n");
		exit(1);
	}

	fscanf(file, "%d", &par->is_julia);
	fscanf(file, "%lf %lf %lf %lf",
			&par->x_min, &par->x_max, &par->y_min, &par->y_max);
	fscanf(file, "%lf", &par->resolution);
	fscanf(file, "%d", &par->iterations);

	if (par->is_julia) {
		fscanf(file, "%lf %lf", &par->c_julia.a, &par->c_julia.b);
	}

	fclose(file);
}


// aloca memorie pentru rezultat
int **allocate_memory(int width, int height)
{
	int **result;
	int i;
	printf("%d \n", height);
	result = malloc(height * sizeof(int*));
	if (result == NULL) {
		printf("Eroare la malloc YAAAAAA!\n");
		exit(1);
	}

	for (i = 0; i < height; i++) {
		result[i] = malloc(width * sizeof(int));
		if (result[i] == NULL) {
			printf("Eroare la malloc YAYAYAY!\n");
			exit(1);
		}
	}

	return result;
}

// elibereaza memoria alocata
void free_memory(int **result, int height)
{
	int i;

	for (i = 0; i < height; i++) {
		free(result[i]);
	}
	free(result);
}



void* thread_function(void* arg) {

	int w, h, i, j;
	int thread_id = *(int *)arg;
	int start_julia = thread_id * (double)width_julia / NUM_THREADS;
	int end_julia = min((thread_id + 1) * (double)width_julia / NUM_THREADS, width_julia);

	for (w = start_julia; w < end_julia; w++) {
		for (h = 0; h < height_julia; h++) {
			int step = 0;
			complex z = { .a = w * par_julia->resolution + par_julia->x_min,
							.b = h * par_julia->resolution + par_julia->y_min };

			while (sqrt(pow(z.a, 2.0) + pow(z.b, 2.0)) < 2.0 && step < par_julia->iterations) {
				complex z_aux = { .a = z.a, .b = z.b };

				z.a = pow(z_aux.a, 2) - pow(z_aux.b, 2) + par_julia->c_julia.a;
				z.b = 2 * z_aux.a * z_aux.b + par_julia->c_julia.b;

				step++;
			}

			result_julia[height_julia - h - 1][w] = step % 256;
		}
	}
	pthread_barrier_wait(&barrier);

	if(thread_id == 0){
		FILE *file = fopen(out_filename_julia, "w");
		/*if (file == NULL) {
			printf("Eroare la deschiderea fisierului de iesire!\n");
			return NULL;
		}*/

		fprintf(file, "P2\n%d %d\n255\n", width_julia, height_julia);
		for (i = 0; i < height_julia; i++) {
			for (j = 0; j < width_julia; j++) {
				fprintf(file, "%d ", result_julia[i][j]);
			}
			fprintf(file, "\n");
		}

		fclose(file);
	}
	

	int start_mandelbrot = thread_id * (double)width_mandelbrot/ NUM_THREADS;
	int end_mandelbrot = min((thread_id + 1) * (double)width_mandelbrot / NUM_THREADS, width_mandelbrot);

	for (w = start_mandelbrot; w < end_mandelbrot; w++) {
		for (h = 0; h < height_mandelbrot; h++) {
			complex c = { .a = w * par_mandelbrot->resolution + par_mandelbrot->x_min,
							.b = h * par_mandelbrot->resolution + par_mandelbrot->y_min };
			complex z = { .a = 0,.b = 0 };
			int step = 0;

			while (sqrt(pow(z.a, 2.0) + pow(z.b, 2.0)) < 2.0 && step < par_mandelbrot->iterations) {
				complex z_aux = { .a = z.a,.b = z.b };

				z.a = pow(z_aux.a, 2.0) - pow(z_aux.b, 2.0) + c.a;
				z.b = 2.0 * z_aux.a * z_aux.b + c.b;

				step++;
			}

			result_mandelbrot[height_mandelbrot - h - 1][w] = step % 256;
		}
	}

	pthread_barrier_wait(&barrier);

	if(thread_id == 0){
		FILE *file = fopen(out_filename_mandelbrot, "w");
		/*if (file == NULL) {
			printf("Eroare la deschiderea fisierului de iesire!\n");
			return NULL;
		}*/

		fprintf(file, "P2\n%d %d\n255\n", width_mandelbrot, height_mandelbrot);
		for (i = 0; i < height_mandelbrot; i++) {
			for (j = 0; j < width_mandelbrot; j++) {
				fprintf(file, "%d ", result_mandelbrot[i][j]);
			}
			fprintf(file, "\n");
		}
		fclose(file);
	}
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	// se citesc argumentele programului
	get_args(argc, argv);

	//julia - initializare
	par_julia = (params*) malloc(sizeof(params));
	read_input_file(in_filename_julia, par_julia);
	width_julia = (par_julia->x_max - par_julia->x_min) / par_julia->resolution;
	height_julia = (par_julia->y_max - par_julia->y_min) / par_julia->resolution;
	result_julia = allocate_memory(width_julia, height_julia);

	//mandelbrot - initializare
	par_mandelbrot = (params*) malloc(sizeof(params));
	read_input_file(in_filename_mandelbrot, par_mandelbrot);
	width_mandelbrot = (par_mandelbrot->x_max - par_mandelbrot->x_min) / par_mandelbrot->resolution;
	height_mandelbrot = (par_mandelbrot->y_max - par_mandelbrot->y_min) / par_mandelbrot->resolution;
	result_mandelbrot = allocate_memory(width_mandelbrot, height_mandelbrot);

	pthread_barrier_init(&barrier, NULL, NUM_THREADS);

	int i, r;
	pthread_t threads[NUM_THREADS];
	int arguments[NUM_THREADS];
	void *status;

	for (i = 0; i < NUM_THREADS; i++) {
		arguments[i] = i;
		r = pthread_create(&threads[i], NULL, thread_function, &arguments[i]);

		if (r) {
			printf("Eroare la crearea thread-ului %d\n", i);
			exit(-1);
		}
	}

	for (i = 0; i < NUM_THREADS; i++) {
		r = pthread_join(threads[i], &status);

		if (r) {
			printf("Eroare la asteptarea thread-ului %d\n", i);
			exit(-1);
		}

	}

	free_memory(result_julia, height_julia);
	free_memory(result_mandelbrot, height_mandelbrot);
	pthread_barrier_destroy(&barrier);

	return 0;
}
